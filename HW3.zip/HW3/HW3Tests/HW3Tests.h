//
//  HW3Tests.h
//  HW3Tests
//
//  Created by Kathleen Urvalek on 7/14/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface HW3Tests : SenTestCase {
@private
    
}

@end
