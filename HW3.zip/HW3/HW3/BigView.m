//
//  BigView.m
//  HW3
//
//  Created by Kathleen Urvalek on 7/14/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "BigView.h"
#import "LittleView0.h"
#import "LittleView1.h"
#import "LittleView2.h"


@implementation BigView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        views = [NSArray arrayWithObjects:
                 [[LittleView0 alloc] initWithFrame: self.bounds],
                 [[LittleView1 alloc] initWithFrame: self.bounds],
                   [[LittleView2 alloc] initWithFrame: self.bounds],
                 nil
                 ];
		
		[views retain];
		index = 0;	//FlipView0 is the one that's initially visible.
        pointBegan = CGPointZero;
        pointMoved = CGPointZero;
        tapCount = 0;
        wearOff = 2;
        self.multipleTouchEnabled = YES;
		[self addSubview: [views objectAtIndex: index]];
    }
    return self;
}

- (void) textInView
{
    UILabel *label = [[UILabel alloc] initWithFrame: CGRectMake(0, 0, 180, 30)];
    label.font = [UIFont boldSystemFontOfSize: 20.0f];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [UIColor whiteColor];
    label.text = displayText;
    [self addSubview: label];    
    [label release];
}

- (void) touchView
{
    //NSLog(@"index: %d", index);
    //NSLog(@"newIndex: %d", newIndex);
    if ((index + 1) == [views count]) {
        newIndex = 0;
    }
    else {
        newIndex = index + 1;	//toggle the index
    }
    
    [UIView transitionFromView: [views objectAtIndex: index]
                        toView: [views objectAtIndex: newIndex]
                      duration: 2
                       options: UIViewAnimationOptionCurveEaseInOut
                    completion: NULL
     ];
    index = newIndex;
    [self textInView];
}


- (void) noTap {	//called when no tap is currently being received
	tapCount = 0;
    //NSLog(@"noTap method is called");
	[self setNeedsDisplay];
    [self touchView];
}


- (void) singleTap {	//called when a single tap is received.
	tapCount = 1;
    displayText = @"SingleTap FlipView";
    //NSLog(@"singleTap method is called");
	[self setNeedsDisplay];
    
	//After a few seconds, the single tap wears off.
	[self performSelector: @selector(noTap) withObject: nil
               afterDelay: wearOff];
}


- (void) doubleTap {	//called when a double tap is received
	tapCount = 2;
    displayText = @"Pinch FlipView";
    //NSLog(@"doubleTap method is called");
	[self setNeedsDisplay];
    
	//After a few seconds, the double tap wears off.
	[self performSelector: @selector(noTap) withObject: nil
               afterDelay: wearOff];
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	NSAssert1(touches.count > 0,
              @"touchesBegan:withEvent: touches.count == %u", touches.count);
	UITouch *t = [touches anyObject];
    
    if (t.tapCount == 2) {
        [NSObject cancelPreviousPerformRequestsWithTarget: self];    
    }
    
    pointBegan = [t locationInView: self];
    swipe = FALSE;
    pinch = FALSE;
    //NSLog(@"pointBegain.x: %f", pointBegan.x);
    /*NSLog(@"pointBegan.y: %f", pointBegan.y);*/
}

- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	NSAssert1(touches.count > 0,
              @"touchesMoved:withEvent: touches.count == %u", touches.count);
    swipe = TRUE;
	UITouch *t = [touches anyObject];
	pointMoved = [t locationInView: self];
    /*NSLog(@"pointMoved.x: %f", pointMoved.x);*/
    /*NSLog(@"pointMoved.y: %f", pointMoved.y);*/
	[self setNeedsDisplay];
}

- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {
	
	/*
     Assume a swipe has just ended.  A more complicated program could
     distinguish between left vs. rightswipes, and perform a
     UIViewAnimationOptionTransitionFlipFromLeft or a
     UIViewAnimationOptionTransitionFlipFromRight.
     
     In UIViewAnimationOptionTransitionFlipFromLeft, the left edge moves
     to the right, and the right edge moves away from the user and to the
     left.
     */
    
    UITouch *t = [touches anyObject];
    
    //NSLog(@"touches.count: %d", t.tapCount);
    
    if (t.tapCount == 1) {
        //NSLog(@"invoking singleTap");
		[self performSelector: @selector(singleTap) withObject: nil
                   afterDelay: 0.3];
	} else if (t.tapCount == 2) {
        //NSLog(@"invoking doubleTap");
        NSArray *a = touches.allObjects;
        current0 = [[a objectAtIndex: 0] locationInView: self];
        /*current1 = [[a objectAtIndex: 1] locationInView: self];*/
        
        previous0 = [[a objectAtIndex: 0] previousLocationInView: self];
        /*previous1 = [[a objectAtIndex: 1] previousLocationInView: self];*/
        pinch = TRUE;
		[self doubleTap];
	}    	
    else {
        //NSLog(@"it is a swipe");
        displayText = @"Swipe FlipView";
        if ((index + 1) == [views count]) {
            newIndex = 0;
        }
        else {
            newIndex = index + 1;	//toggle the index
        }
        
        //NSLog(@"pointBegan.x: %f", pointBegan.x);
        //NSLog(@"pointBegan.y: %f", pointBegan.y);
        //NSLog(@"pointMoved.x: %f", pointMoved.x);
        //NSLog(@"pointMoved.y: %f", pointMoved.y);
        if (pointBegan.x < pointMoved.x &&
            pointBegan.y < pointMoved.y) { /* swipe left */
            [UIView transitionFromView: [views objectAtIndex: index]
                                toView: [views objectAtIndex: newIndex]
                              duration: 2
                               options: UIViewAnimationOptionTransitionCurlDown
                            completion: NULL
             ];
        }
        else if (pointBegan.x > pointMoved.x &&
                 pointBegan.y > pointMoved.y) { /* swipe right */
            [UIView transitionFromView: [views objectAtIndex: index]
                                toView: [views objectAtIndex: newIndex]
                              duration: 2
                               options: UIViewAnimationOptionTransitionCurlUp
                            completion: NULL
             ];
        }
        else if (pointBegan.x > pointMoved.x &&
                 pointBegan.y < pointMoved.y) { /* swipe down */
            [UIView transitionFromView: [views objectAtIndex: index]
                                toView: [views objectAtIndex: newIndex]
                              duration: 2
                               options: UIViewAnimationOptionTransitionFlipFromRight
                            completion: NULL
             ];
        }
        else { /* swipe up */
            [UIView transitionFromView: [views objectAtIndex: index]
                                toView: [views objectAtIndex: newIndex]
                              duration: 2
                               options: UIViewAnimationOptionTransitionFlipFromLeft
                            completion: NULL
             ];
        }
        
        index = newIndex;
        [self textInView];
    }
    
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)dealloc
{
    for (UIView *v in views) {
		[v release];
	}
	
	[views release];
    [super dealloc];
}

@end
