//
//  LittleView2.m
//  HW3
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "LittleView2.h"

@implementation LittleView2

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor blackColor];
        CGRect f = CGRectMake(0, 0, 320, 480);
        imageLittleView2 = [[UIImageView alloc] initWithFrame: f];
        [imageLittleView2 setImage:[UIImage imageNamed: @"bricks.png"]];
        imageLittleView2.opaque = YES;
        [self addSubview: imageLittleView2];
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/
    
    - (void)dealloc
    {
        [super dealloc];
    }
    
@end
