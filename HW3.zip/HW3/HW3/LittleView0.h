//
//  LittleView0.h
//  HW3
//
//  Created by Kathleen Urvalek on 7/14/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LittleView0 : UIView {
    UIImageView *imageLittleView0;
    
}

@end
