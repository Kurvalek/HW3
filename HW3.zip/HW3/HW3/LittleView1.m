//
//  LittleView1.m
//  HW3
//
//  Created by Kathleen Urvalek on 7/14/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "LittleView1.h"


@implementation LittleView1

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor blackColor];
        CGRect f = CGRectMake(0, 0, 320, 480);
        imageLittleView1 = [[UIImageView alloc] initWithFrame: f];
        [imageLittleView1 setImage:[UIImage imageNamed: @"chalkboard.png"]];
        imageLittleView1.opaque = YES;
        [self addSubview: imageLittleView1];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 UIFont *f = [UIFont systemFontOfSize: 32];
 [@"FlipView1" drawAtPoint: CGPointZero withFont: f];
 }
 */


- (void)dealloc
{
    [super dealloc];
}

@end
