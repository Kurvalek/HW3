//
//  HW3AppDelegate.h
//  HW3
//
//  Created by Kathleen Urvalek on 7/14/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BigView;

@interface HW3AppDelegate : NSObject <UIApplicationDelegate> {
    BigView *bigView;
    UIWindow *window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
