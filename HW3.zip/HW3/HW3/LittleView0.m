//
//  LittleView0.m
//  HW3
//
//  Created by Kathleen Urvalek on 7/14/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "LittleView0.h"


@implementation LittleView0

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor blackColor];
        CGRect f = CGRectMake(0, 0, 320, 480);
        imageLittleView0 = [[UIImageView alloc] initWithFrame: f];
        [imageLittleView0 setImage:[UIImage imageNamed: @"cork.png"]];
        imageLittleView0.opaque = YES;
        [self addSubview: imageLittleView0];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 UIFont *f = [UIFont systemFontOfSize: 32];
 [@"FlipView0" drawAtPoint: CGPointZero withFont: f];
 }
 
 */

- (void)dealloc
{
    [super dealloc];
}

@end
